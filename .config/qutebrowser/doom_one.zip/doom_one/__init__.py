# SPDX-FileCopyrightText: 2025 Rehpotsirhc
#
# SPDX-License-Identifier: MIT

from .setup import setup
